//FLYCE32 INSIDE!
const int N = 1e5 + 1, P = 601, M = 1e9 + 9;

string S;
int p[N], h[N];
void calc(){
    p[0] = 1, h[0] = S[0];
    for (int i = 1; i < S.size(); ++ i){
        p[i] = (p[i - 1] * 1LL * P) % M;
        h[i] = ((h[i - 1] * 1LL * P) + S[i]) % M;
    }
}
int get(int l, int r){
    int pr = l ? h[l - 1] : 0;
    return (h[r] + M - (pr * 1LL * p[r - l + 1]) % M) % M;
}
bool ls(int l1, int r1, int l2, int r2){
    int len1 = r1 - l1 + 1, len2 = r2 - l2 + 1,
        l = 0, r = min(len1, len2);
    while (l < r){
        int m = (l + r) >> 1;
        if (get(l1, l1 + m) == get(l2, l2 + m))
            l = m + 1;
        else r = m;
    }
    if (l == len2) return 0;
    if (l == len1) return 1;
    return S[l1 + l] < S[l2 + l];
}
