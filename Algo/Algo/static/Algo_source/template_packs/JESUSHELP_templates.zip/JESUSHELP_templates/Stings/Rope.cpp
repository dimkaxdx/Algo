#ifdef __ROPE__
#include <ext/rope>
using namespace __gnu_cxx;
#endif
rope < int > rp;
for (int i = 0; i < n; ++ i){
    rp.push_back(i + 1);
}
while (m --){
    int l, r;
    read(l, r);
    -- l, -- r;
    auto cur = rp.substr(l, r - l + 1);
    rp.erase(l, r - l + 1);
    rp.insert(rp.mutable_begin(), cur);
}
