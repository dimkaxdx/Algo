//n! % (k^x) == 0. x -> max. k -- PRIME. O(log(k, n)).
int fact_pow (int n, int k)
{
	int res = 0;
	while (n)
    {
		n /= k;
		res += n;
	}
	return res;
}
//IF k -- complex.
//1. factorize k.
//2. solve for all factors.
//3. choose min of all results.
