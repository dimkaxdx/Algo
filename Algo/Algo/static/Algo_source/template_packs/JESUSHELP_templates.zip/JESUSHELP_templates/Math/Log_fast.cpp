//Flyce32 power inside!
ll lg(ll x){
    return __builtin_clzll(1) - __builtin_clzll(x);
}
