//a * x == 1   (mod m); O(log(m));
int rev(int a, int m)
{
    int x, y;
    int g = gcdex(a, m, x, y); //Eulid_extended.cpp
    if (g != 1)
    	return -1;
    x = (x % m + m) % m;
    return x;
}

//ALL in [1; m-1]; O(m). m -- PRIME!
vector<int> find_all(int m)
{
    vector<int> res(m);
    res[1] = 1;
    for (int i = 2 ; i < m ; i ++)
        res[i] = (m - (m/i) * res[m%i] % m) % m;
    return res;
}
