//Funciya eulera -- kolvo chisel [1; n], vzaimnoprostih s n.
//__gcd(num, n) == 1 --> True;
//Teorem Eulera: a^(phi(m)) == 1  (mod m)
//O(sqrt(N)).
int phi (int n)
{
	int result = n;
	for (int i = 2 ; i * i <= n ; i ++)
		if (n % i == 0)
        {
			while (n % i == 0)
				n /= i;
			result -= result / i;
		}
	if (n > 1)
		result -= result / n;
	return result;
}
