//sqrt (mnogo koda).
//проинициализируем переменную b значением 1,
//и пока b не является корнем из a (то есть неверно, что b^2 <= a и (b+1)^2 > a),
//заменять b на (b + a/b)/2. PYTHON!!!!
const int base = 1e9;
void multLongOnLong(vector<int>& a, vector<int>& b)
{
    vector<int> c (a.size()+b.size());
    for (size_t i=0; i<a.size(); ++i)
    	for (int j=0, carry=0; j<(int)b.size() || carry; ++j) {
    		long long cur = c[i+j] + a[i] * 1ll * (j < (int)b.size() ? b[j] : 0) + carry;
    		c[i+j] = int (cur % base);
    		carry = int (cur / base);
    	}
    while (c.size() > 1 && c.back() == 0)
    	c.pop_back();
    a = c;
}
void divLongOnShort(vector<int>& a, int b) //(b <= BASE)
{
    int carry = 0;
    for (int i=(int)a.size()-1; i>=0; --i) {
    	long long cur = a[i] + carry * 1ll * base;
    	a[i] = int (cur / b);
    	carry = int (cur % b);
    }
    while (a.size() > 1 && a.back() == 0)
    	a.pop_back();
}
