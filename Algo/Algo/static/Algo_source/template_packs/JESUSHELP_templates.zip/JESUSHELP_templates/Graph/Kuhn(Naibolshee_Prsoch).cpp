//O(NM).
//Дан двудольный граф G, содержащий n вершин и m рёбер.
//Требуется найти наибольшее паросочетание, т.е. выбрать как можно больше рёбер,
//чтобы ни одно выбранное ребро не имело общей вершины ни с каким другим выбранным ребром.
int main() {
        ... чтение графа ...
        mt.assign (k, -1);
        vector<char> used1 (n);
        for (int i=0; i<n; ++i)
                for (size_t j=0; j<g[i].size(); ++j)
                        if (mt[g[i][j]] == -1) {
                                mt[g[i][j]] = i;
                                used1[i] = true;
                                break;
                        }
        for (int i=0; i<n; ++i) {
                if (used1[i])  continue;
                used.assign (n, false);
                try_kuhn (i);
        }

        for (int i=0; i<k; ++i)
                if (mt[i] != -1)
                        printf ("%d %d\n", mt[i]+1, i+1);
}
