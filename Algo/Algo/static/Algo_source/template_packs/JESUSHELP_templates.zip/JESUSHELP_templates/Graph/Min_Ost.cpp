//KRUSKALA. Min ostov. O(M*logN).
vector<int> p (n);
int dsu_get (int v) {
	return (v == p[v]) ? v : (p[v] = dsu_get (p[v]));
}
void dsu_unite (int a, int b) {
	a = dsu_get (a);
	b = dsu_get (b);
	if (rand() & 1)
		swap (a, b);
	if (a != b)
		p[a] = b;
}
... in main(): ...
int m;
vector < pair < int, pair<int,int> > > g; // weight - first vertex - second vertex
... read graph ...
int cost = 0;
vector < pair<int,int> > res;
sort (g.begin(), g.end());
p.resize (n);
for (int i=0; i<n; ++i)
	p[i] = i;
for (int i=0; i<m; ++i) {
	int a = g[i].second.first,  b = g[i].second.second,  l = g[i].first;
	if (dsu_get(a) != dsu_get(b)) {
		cost += l;
		res.push_back (g[i].second);
		dsu_unite (a, b);
	}
}

//PRIMA. O(N^2). //matrix g[][].
int n;
vector < vector<int> > g;
const int INF = 1e9 + 7; // значение "бесконечность"
vector<bool> used (n);
vector<int> min_e (n, INF), sel_e (n, -1);
min_e[0] = 0;
for (int i=0; i<n; ++i) {
	int v = -1;
	for (int j=0; j<n; ++j)
		if (!used[j] && (v == -1 || min_e[j] < min_e[v]))
			v = j;
	if (min_e[v] == INF) {
		cout << "No MST!";
		exit(0);
	}
	used[v] = true;
	if (sel_e[v] != -1)
		cout << v << " " << sel_e[v] << endl;
	for (int to=0; to<n; ++to)
		if (!used[to] && g[v][to] < min_e[to]) {
			min_e[to] = g[v][to];
			sel_e[to] = v;
		}
}
