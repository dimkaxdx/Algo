//OW! U come here.... Are u sure?
//maybe think about task and find another solve?
//DANGERRRRRRRR! Treapppppppppp....
//oh, if u sure, so:
//Treappppp with key
#include <bits/stdc++.h>

using namespace std;

mt19937 gen(chrono::system_clock::now().time_since_epoch().count());

int mygcd(int x, int y)
{
    if (x == 0 || y == 0) return x + y;
    return __gcd(x, y);
}

struct Node
{
    int x, y, sz;
    int gcd;
    long long sum;
    Node *l = nullptr, *r = nullptr;;

    Node() {}
    Node(int x): x(x), y(gen() % 1000000000), l(nullptr), r(nullptr), sz(1), sum(x), gcd(x) {}

    int size_of(Node *a)
    {
        if(a) return a->sz;
        return 0;
    }
    long long sum_of(Node *a)
    {
        if(a) return a->sum;
        return 0;
    }
    int gcd_of(Node *a)
    {
        if(a) return a->gcd;
        return 0;
    }

    void update()
    {
        sz = 1 + size_of(l) + size_of(r);
        sum = x + sum_of(l) + sum_of(r);
        gcd = mygcd(x, mygcd(gcd_of(l), gcd_of(r)));
    }

    int kth(int k)
    {
        int sz = size_of(l);
        if (sz + 1 == k) return x;
        if (k <= sz) return l->kth(k);
        return r->kth(k - 1 - sz);
    }
    void print()
    {
        if(l) l->print();
        cout << x << ' ';
        if(r) r->print();
    }
};

struct Treap
{
    Node *root;
    Treap(): root(0) {}
    void merge(Node *l, Node *r, Node *&v)
    {
         if (!l || !r) return void(v = l ? l : r);
         if (l->y > r->y)
         {
            v = r;
            merge(l, r->l, v->l);
         } else {
            v = l;
            merge(l->r, r, v->r);
         }
         v->update();
    }
    void split(Node *t, int key, Node *&l, Node *&r)
    {
        if (!t) return void(l = r = nullptr);
        if (t->x <= key)
        {
            l = t;
            split(t->r, key, l->r, r);
            l->update();
        } else {
            r = t;
            split(t->l, key, l, r->l);
            r->update();
        }
    }

    void add(int x)
    {
        Node *a, *b;
        split(root, x, a, b);
        merge(a, new Node(x), a);
        merge(a, b, root);
    }
    void del(int x)
    {
        Node *a, *b;
        split(root, x, a, b);
        Node *c, *d;
        split(a, x - 1, c, d);
        if(root->size_of(d) != 0)
        {
            merge(c, d->l, c);
            merge(c, d->r, c);
        }
        merge(c, b, root);
    }

    long long sum(int L, int R)
    {
        Node *a, *b;
        split(root, R, a, b);
        Node *c, *d;
        split(a, L - 1, c, d);
        long long res = root->sum_of(d);
        merge(c, d, a);
        merge(a, b, root);
        return res;
    }
    int gcd(int L, int R)
    {
        Node *a, *b;
        split(root, R, a, b);
        Node *c, *d;
        split(a, L - 1, c, d);
        int res = root->gcd_of(d);
        merge(c, d, a);
        merge(a, b, root);
        return res;
    }
    int kth(int x)
    {
        return root->kth(x);
    }

    void print()
    {
        root->print();
        cout << endl;
    }
};

int main()
{
    Treap t;
    int n; cin >> n;
    for(int i = 0 ; i < n ; i ++)
    {
        int a; cin >> a;
        t.add(a);
    }
    string s = " ";
    while(s != "exit")
    {
        cin >> s;
        if(s == "sum")
        {
            int l, r;
            cin >> l >> r;
            cout << t.sum(l, r) << endl;
        }
        if(s == "gcd")
        {
            int l, r;
            cin >> l >> r;
            cout << t.gcd(l, r) << endl;
        }
        if(s == "kth")
        {
            int x;
            cin >> x;
            cout << t.kth(x) << endl;
        }
        if(s == "del")
        {
            int x;
            cin >> x;
            t.del(x);
            cout << "Deleted" << endl;
        }
        if(s == "add")
        {
            int val;
            cin >> val;
            t.add(val);
            cout << "Added" << endl;
        }
        if(s == "print")
        {
            t.print();
        }
    }
}

//Treap without key + PUSH. BE CAREFULL. PLS.
#include <bits/stdc++.h>

using namespace std;

mt19937 gen(chrono::system_clock::now().time_since_epoch().count());

struct Node
{
    int val, y;
    Node *l, *r;
    int add;
    long long sum;
    int sz;

    Node() {}
    Node(int val): val(val), y(gen() % 1000000000), l(0), r(0), sz(1), add(0), sum(val) {}

    int size_of(Node *a)
    {
        if(a) return a->sz;
        return 0;
    }
    long long sum_of(Node *a)
    {
        if(a) return a->sum;
        return 0;
    }

    void update()
    {
        sz = 1 + size_of(l) + size_of(r);
        sum = val + sum_of(l) + sum_of(r);
    }
    void print()
    {
        if(l) l->print();
        cout << val << ' ';
        if(r) r->print();
    }
};

struct Treap
{
    Node *root;

    Treap(): root(0) {}

    void push(Node *v)
    {
        if(!v || v->add == 0) return;
        int add = v->add;
        v->sum += v->sz*add;
        v->val += add;
        v->add = 0;
        if(v->l) v->l->add += add;
        if(v->r) v->r->add += add;
    }
    void merge(Node *l, Node *r, Node *&v)
    {
        if(l) push(l);
        if(r) push(r);
        if (!l || !r) return void(v = l ? l : r);
        if (l->y > r->y)
        {
            v = r;
            merge(l, r->l, v->l);
        }
        else
        {
            v = l;
            merge(l->r, r, v->r);
        }
        v->update();
    }
    void split(Node *t, int x, Node *&l, Node *&r)
    {
        if(!t) return void(l = r = nullptr);
        push(t);
        int sz = t->size_of(t->l) + 1;
        if(x < sz)
        {
            r = t;
            split(t->l, x, l, r->l);
            r->update();
        }
        else
        {
            l = t;
            split(t->r, x-sz, l->r, r);
            l->update();
        }
    }

    void insert(int val, int pos)
    {
        Node *a, *b;
        split(root, pos, a, b);
        merge(a, new Node(val), a);
        merge(a, b, root);
    }
    void add(int L, int R, int val)
    {
        Node *a, *b;
        split(root, L-1, a, b);
        Node *c, *d;
        split(b, R-L+1, c, d);
        if(c) c->add += val;
        merge(c, d, b);
        merge(a, b, root);
    }
    void del(int L, int R)
    {
        Node *a, *b;
        split(root, L-1, a, b);
        Node *c, *d;
        split(b, R-L+1, c, d);
        merge(a, d, root);
    }

    long long sum(int L, int R)
    {
        Node *a, *b;
        split(root, L-1, a, b);
        Node *c, *d;
        split(b, R-L+1, c, d);
        int res = c->sum;
        merge(c, d, b);
        merge(a, b, root);
        return res;
    }

    void print()
    {
        //WE NEED TO PUSH. ONLY DEBUG. OUTPUT CAN BE WRONG! (THIS IS NOT BUG).
        root->print();
        cout << endl;
    }

};

int main()
{
    Treap t;
    int n; cin >> n;
    for(int i = 1 ; i <= n ; i ++)
    {
        int a; cin >> a;
        t.insert(a, i);
    }
    string s = " ";
    while(s != "exit")
    {
        cin >> s;
        if(s == "sum")
        {
            int l, r;
            cin >> l >> r;
            cout << t.sum(l, r) << endl;
        }
        if(s == "del")
        {
            int l, r;
            cin >> l >> r;
            t.del(l, r);
            cout << "Deleted" << endl;
        }
        if(s == "insert")
        {
            int val, pos;
            cin >> val >> pos;
            t.insert(val, pos);
            cout << "Inserted" << endl;
        }
        if(s == "add")
        {
            int l, r, val;
            cin >> l >> r >> val;
            t.add(l, r, val);
            cout << "Added" << endl;
        }
        if(s == "print")
        {
            t.print();
        }
    }
}
