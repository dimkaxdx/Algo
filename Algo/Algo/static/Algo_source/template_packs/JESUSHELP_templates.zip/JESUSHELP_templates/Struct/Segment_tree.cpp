//FLYCE32 POWER START.
//1D Implicit ST.
const int N = 1e5 + 1, DO = N << 4;

int leaf, t[DO], lptr[DO],
    rptr[DO], a[N];
void push(int v){
    if (!lptr[v]) lptr[v] = ++ leaf,
        rptr[v] = ++ leaf;
}
int update(int v, int tl, int tr, int idx, int val){
    if (tl == tr) return t[v] = val;
    push(v);
    int lft = lptr[v], rht = rptr[v],
        tm = (tl + tr) >> 1;
    if (idx > tm) return t[v] = t[lft] + update(rht, tm + 1, tr, idx, val);
    return t[v] = t[rht] + update(lft, tl, tm, idx, val);
}
int get(int v, int tl, int tr, int l, int r){
    if (l > r) return 0;
    if (tl >= l && tr <= r) return t[v];
    push(v);
    int lft = lptr[v], rht = rptr[v],
        tm = (tl + tr) >> 1, res = 0;
    if (l <= tm) res = get(lft, tl, tm, l, r);
    if (r > tm) res += get(rht, tm + 1, tr, l, r);
    return res;
}
int get(int v, int tl, int tr, int k){
    while (tl < tr){
        push(v);
        int lft = lptr[v], rht = rptr[v], tm = (tl + tr) >> 1;
        if (k > tm - tl + 1 - t[lft])
            v = rht, k -= tm - tl + 1 - t[lft],
            tl = tm + 1;
        else v = lft, tr = tm;
    }
    return tl;
}

//2D Implicit ST
const int N = 1e5 + 1, MAX = 1e6, DO = N << 4;

int sf = 1, st[DO], sl[DO], sr[DO];
int scr(int& v){
    if (!v) v = ++ sf;
    return v;
}
int smod(int v, int tl, int tr, int i, int val){
    if (tl == tr) return st[v] += val;
    int &lft = sl[v], &rht = sr[v],
        tm = (tl + tr) >> 1;
    if (i > tm) return st[v] = st[scr(lft)] + smod(scr(rht), tm + 1, tr, i, val);
    return st[v] = st[scr(rht)] + smod(scr(lft), tl, tm, i, val);
}
int sget(int v, int tl, int tr, int l, int r){
    if (tl >= l && tr <= r) return st[v];
    int &lft = sl[v], &rht = sr[v],
        tm = (tl + tr) >> 1, res = 0;
    if (l <= tm) res = sget(scr(lft), tl, tm, l, r);
    if (r > tm) res += sget(scr(rht), tm + 1, tr, l, r);
    return res;
}

int ff = 1, ft[DO], fl[DO], fr[DO];
int fcr(int& v){
    if (!v) scr(ft[v = ++ ff]);
    return v;
}
void fmod(int v, int tl, int tr, int i, int j, int val){
    while (true){
        smod(scr(ft[v]), 0, MAX, j, val);
        if (tl == tr) break;
        int &lft = fl[v], &rht = fr[v],
            tm = (tl + tr) >> 1;
        if (i > tm) v = fcr(rht), tl = tm + 1;
        else v = fcr(lft), tr = tm;
    }
}
int fget(int v, int tl, int tr, int l, int r, int x, int y){
    if (tl >= l && tr <= r) return sget(scr(ft[v]), 0, MAX, x, y);
    int &lft = fl[v], &rht = fr[v],
        tm = (tl + tr) >> 1, res = 0;
    if (l <= tm) res = fget(fcr(lft), tl, tm, l, r, x, y);
    if (r > tm) res += fget(fcr(rht), tm + 1, tr, l, r, x, y);
    return res;
}

//Imp Persistent ST
const int N = 1e5 + 1, DO = N << 4;

int leaf, lft[DO], rht[DO], t[DO],
    root[N], sz = 1;
void push(int v){
    if (!lft[v]) lft[v] = ++ leaf;
    if (!rht[v]) rht[v] = ++ leaf;
}
int mod(int tl, int tr, int idx,
        int old, int rec, int val){
    if (tl == tr) return t[rec] = val;
    int tm = (tl + tr) >> 1,
        &lo = lft[old], &ro = rht[old],
        &lr = lft[rec], &rr = rht[rec];
    push(old), push(rec);
    if (idx > tm)
        return t[rec] = t[lr = lo]
                + mod(tm + 1, tr, idx,
                ro, rr = ++ leaf, val);
    else
        return t[rec] = t[rr = ro]
                + mod(tl, tm, idx,
                lo, lr = ++ leaf, val);
}
int get(int v, int tl, int tr, int l, int r){
    if (tl >= l && tr <= r) return t[v];
    int tm = (tl + tr) >> 1, res = 0;
    if (r > tm) res = get(rht[v], tm + 1, tr, l, r);
    if (l <= tm) res += get(lft[v], tl, tm, l, r);
    return res;
}

int main(){
    int n = input(), q = input();
    for (int i = 0; i < q; ++ i){
        char c; cin >> c;
        if (c == '?'){
            int v = input(), l = input() - 1, r = input() - 1;
            cout << get(root[v], 0, n - 1, l, r) << "\n";
        }else{
            int old = input(), idx = input() - 1, val = input();
            mod(0, n - 1, idx, root[old], root[sz ++] = ++ leaf, val);
        }
    }
}

//Pure ST
const int N = 1e5 + 1;

int a[N], t[N << 3];
int build(int v, int tl, int tr){
    if (tl == tr) return t[v] = a[tl];
    int x = v << 1, tm = (tl + tr) >> 1;
    return t[v] = min(build(x, tl, tm), build(x + 1, tm + 1, tr));
}
int update(int v, int tl, int tr, int idx, int val){
    if (tl == tr) return t[v] = val;
    int x = v << 1, tm = (tl + tr) >> 1;
    if (idx > tm) return t[v] = min(t[x], update(x + 1, tm + 1, tr, idx, val));
    return t[v] = min(t[x + 1], update(x, tl, tm, idx, val));
}
int get(int v, int tl, int tr, int l, int r){
    if (tl >= l && tr <= r) return t[v];
    int x = v << 1, tm = (tl + tr) >> 1, res = 1e9;
    if (l <= tm) res = get(x, tl, tm, l, r);
    if (r > tm) res = min(res, get(x + 1, tm + 1, tr, l, r));
    return res;
}

//FLYCE32 POWER END.

//ST add on range

const int N = 1e5 + 7;

int lazy[4*N];
int tree[4*N];

void updateRange(int node, int start, int end, int l, int r, int val)
{
    if(lazy[node] != 0)
    {
        tree[node] += (end - start + 1) * lazy[node];
        if(start != end)
        {
            lazy[node*2] += lazy[node];
            lazy[node*2+1] += lazy[node];
        }
        lazy[node] = 0;
    }
    if(start > end or start > r or end < l)
        return;
    if(start >= l and end <= r)
    {
        tree[node] += (end - start + 1) * val;
        if(start != end)
        {
            lazy[node*2] += val;
            lazy[node*2+1] += val;
        }
        return;
    }
    int mid = (start + end) / 2;
    updateRange(node*2, start, mid, l, r, val);
    updateRange(node*2 + 1, mid + 1, end, l, r, val);
    tree[node] = tree[node*2] + tree[node*2+1];
}

int queryRange(int node, int start, int end, int l, int r)
{
    if(start > end or start > r or end < l)
        return 0;
    if(lazy[node] != 0)
    {
        tree[node] += (end - start + 1) * lazy[node];
        if(start != end)
        {
            lazy[node*2] += lazy[node];
            lazy[node*2+1] += lazy[node];
        }
        lazy[node] = 0;
    }
    if(start >= l and end <= r)
        return tree[node];
    int mid = (start + end) / 2;
    int p1 = queryRange(node*2, start, mid, l, r);
    int p2 = queryRange(node*2 + 1, mid + 1, end, l, r);
    return (p1 + p2);
}
