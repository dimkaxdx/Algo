//FLYCE32 INSIDE!
pair <int, int> v[N];
int main(){
    int n = input();
    for (int i = 0; i < n; ++ i)
        v[i] = {a[i] = input(), i};
    sort(v, v + n);
    for (int i = 0, d = 0; i < n; ++ i){
        if (i && v[i].first > v[i - 1].first) ++ d;
        a[v[i].second] = d;
}
