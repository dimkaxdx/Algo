__builtin_popcount(x) - count of bits in x, __builtin_popcountll

__builtin_clz(x) - count of leading zeros in x, __builtin_clzll
