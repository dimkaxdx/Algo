/*
Отче наш, иже еси в моем PC,
Да святится имя и расширение Твое,
Да придет прерывание Твое
И да будет воля Твоя
AC наш насущный дай нам,
И прости нам дизассемблеры
и баги наши,
как Копирайты прощаем мы.
И не введи нас в TL,
но избавь нас от WA,
ибо Твое есть адресное пространство, порты и регистры
Во имя C++, Java и святого Python,
всемогущего Assembly во веки веков.
Admin!!!
*/
#include <bits/stdc++.h>

namespace Help
{
    bool Flyce_Boosts = true;
    bool Dmitrycpp_antitupin = true;
    bool Derovi_genius_mode = true;
    bool JESUS_help = true;
}

using namespace std;
using namespace Help;

int input(){
    int res = 0; char c = ' ';
    while (c < '0') c = getchar();
    while (c >= '0') res = res * 10 + (c - '0'), c = getchar();
    return res;

}

int32_t main()
{
    return ("JESUS" == "HELP");
}
