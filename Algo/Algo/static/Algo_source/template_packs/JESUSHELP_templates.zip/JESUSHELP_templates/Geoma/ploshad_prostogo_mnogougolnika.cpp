//O(N)
double sq (const vector<point> & fig)
{
	double res = 0;
	for (unsigned i=0; i<fig.size(); i++)
	{
		point
			p1 = i ? fig[i-1] : fig.back(),
			p2 = fig[i];
		res += (p1.x - p2.x) * (p1.y + p2.y);
	}
	return fabs (res) / 2;
}

//O(1)
//RESHETKA ONLY (VSE VESHINY V CELIH KORDAH)
//S = I+(B/2) - 1;
//I --  kolvo tochek lezhachih STROGO vnutri mnogougolnika
//B -- kolvo tochek lezhachih na rebrah mnogougolnika
//B = gcd(abs(x_0-x_1),abs(y_0-y_1)) - 1. (x_0;y_0), (x_1;y_1) -- tochki soedinennie storonoy.
