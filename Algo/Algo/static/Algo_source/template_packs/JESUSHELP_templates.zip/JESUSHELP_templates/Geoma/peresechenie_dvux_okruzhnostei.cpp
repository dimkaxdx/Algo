//kak i priamay + okruzhnost'
// Ax + By + C = 0,
// A = -2*x2,
// B = -2*y2,
// C = x2^2 + y2^2 + r1^2 - r2^2.
